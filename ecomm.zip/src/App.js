import React, { Component } from 'react';
import { Login } from './admin';
import Routes from './admin/routes';

class App extends Component {
  render() {
    return (
      <Routes />
  );
  }
}

export default App;
