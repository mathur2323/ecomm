import React, { Component } from 'react'

export class Users extends Component {
    render() {
        return (
            <div>
                <h1>Users</h1>
            </div>
        )
    }
}

export default Users
